using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Domain;

namespace Server
{
    class Program
    {
        // Mrežna konfiguracija
        private const int UDP_PORT = 5000;
        private const int TCP_PORT = 5001;
        private const int MIN_IGRACA_ZA_TURNIR = 4;

        // Socket-i
        private static Socket udpSocket;
        private static Socket tcpSocket;

        // Podaci o igračima i turniru
        private static List<Igrac> prijavljeniIgraci = new List<Igrac>();
        private static Dictionary<int, Socket> tcpKlijenti = new Dictionary<int, Socket>();
        private static Dictionary<int, IPEndPoint> udpEndpointi = new Dictionary<int, IPEndPoint>();
        private static int sledecaIdIgraca = 1;

        // Trenutni meč
        private static Mec trenutniMec;
        private static List<Mec> odigraniMecevi = new List<Mec>();
        private static bool turnirUToku = false;
        private static Queue<Tuple<Igrac, Igrac>> parovi = new Queue<Tuple<Igrac, Igrac>>();

        // Thread sync
        private static object lockObj = new object();
        private static bool serverAktivan = true;

        static void Main(string[] args)
        {
            Console.Title = "PingPong Server";
            Console.WriteLine("=== PING PONG SERVER ===");
            Console.WriteLine($"UDP Port: {UDP_PORT}");
            Console.WriteLine($"TCP Port: {TCP_PORT}");
            Console.WriteLine("========================\n");

            // Pokreni UDP socket za prijavu
            udpSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            udpSocket.Bind(new IPEndPoint(IPAddress.Any, UDP_PORT));
            Console.WriteLine("[UDP] Server pokrenut, čekam prijave igrača...");

            // Pokreni TCP socket
            tcpSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            tcpSocket.Bind(new IPEndPoint(IPAddress.Any, TCP_PORT));
            tcpSocket.Listen(10);
            Console.WriteLine("[TCP] Listener pokrenut...");

            // Thread za prijem UDP poruka
            Thread udpThread = new Thread(PrimiUdpPoruke);
            udpThread.IsBackground = true;
            udpThread.Start();

            // Thread za prijem TCP konekcija
            Thread tcpThread = new Thread(PrimiTcpKonekcije);
            tcpThread.IsBackground = true;
            tcpThread.Start();

            // Glavni loop
            Console.WriteLine("\nKomande:");
            Console.WriteLine("  [S] - Pokreni turnir");
            Console.WriteLine("  [L] - Prikaži prijavljene igrače");
            Console.WriteLine("  [R] - Prikaži rang listu");
            Console.WriteLine("  [Q] - Izlaz\n");

            while (serverAktivan)
            {
                if (Console.KeyAvailable)
                {
                    var key = Console.ReadKey(true);
                    switch (char.ToUpper(key.KeyChar))
                    {
                        case 'S':
                            PokreniTurnir();
                            break;
                        case 'L':
                            PrikaziIgrace();
                            break;
                        case 'R':
                            PrikaziRangListu();
                            break;
                        case 'Q':
                            serverAktivan = false;
                            break;
                    }
                }
                Thread.Sleep(50);
            }

            // Cleanup
            udpSocket?.Close();
            tcpSocket?.Close();
            Console.WriteLine("\nServer zaustavljen.");
        }

        static void PrimiUdpPoruke()
        {
            byte[] buffer = new byte[4096];
            EndPoint remoteEP = new IPEndPoint(IPAddress.Any, 0);

            while (serverAktivan)
            {
                try
                {
                    if (udpSocket.Available > 0)
                    {
                        int bytesRead = udpSocket.ReceiveFrom(buffer, ref remoteEP);
                        byte[] data = new byte[bytesRead];
                        Array.Copy(buffer, data, bytesRead);
                        ObradiUdpPoruku(data, (IPEndPoint)remoteEP);
                    }
                    else
                    {
                        Thread.Sleep(10);
                    }
                }
                catch (SocketException ex)
                {
                    if (serverAktivan)
                        Console.WriteLine($"[UDP Greška] {ex.Message}");
                }
            }
        }

        static void ObradiUdpPoruku(byte[] data, IPEndPoint remoteEP)
        {
            try
            {
                Poruka poruka = Poruka.Deserijalizuj(data);

                switch (poruka.Tip)
                {
                    case TipPoruke.ZahtjevZaPrijavu:
                        ObradiPrijavu(poruka, remoteEP);
                        break;
                    case TipPoruke.PomjeriGore:
                        ObradiKomanduIgraca(poruka.IgracId, -1);
                        break;
                    case TipPoruke.PomjeriDole:
                        ObradiKomanduIgraca(poruka.IgracId, 1);
                        break;
                    case TipPoruke.Ping:
                        PosaljiUdpOdgovor(new Poruka(TipPoruke.Pong), remoteEP);
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[UDP Greška] Obrada poruke: {ex.Message}");
            }
        }

        static void ObradiPrijavu(Poruka poruka, IPEndPoint remoteEP)
        {
            lock (lockObj)
            {
                // Deserijalizuj podatke igrača
                Igrac noviIgrac = Igrac.Deserijalizuj(poruka.Podaci);
                noviIgrac.Id = sledecaIdIgraca++;
                noviIgrac.UdpEndPoint = remoteEP;

                prijavljeniIgraci.Add(noviIgrac);
                udpEndpointi[noviIgrac.Id] = remoteEP;

                Console.WriteLine($"[PRIJAVA] Novi igrač: {noviIgrac.Ime} {noviIgrac.Prezime} (ID: {noviIgrac.Id})");
                Console.WriteLine($"          UDP Endpoint: {remoteEP}");
                Console.WriteLine($"          Ukupno igrača: {prijavljeniIgraci.Count}");

                // Pošalji potvrdu
                Poruka odgovor = new Poruka(TipPoruke.PotvrdaPrijave);
                noviIgrac.TcpPort = TCP_PORT;
                odgovor.Podaci = noviIgrac.Serijalizuj();
                odgovor.IgracId = noviIgrac.Id;
                odgovor.Tekst = $"Uspješna prijava! Vaš ID: {noviIgrac.Id}";

                PosaljiUdpOdgovor(odgovor, remoteEP);
            }
        }

        static void PosaljiUdpOdgovor(Poruka poruka, IPEndPoint endPoint)
        {
            try
            {
                byte[] data = poruka.Serijalizuj();
                udpSocket.SendTo(data, endPoint);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[UDP Greška] Slanje: {ex.Message}");
            }
        }

        static void ObradiKomanduIgraca(int igracId, int smjer)
        {
            lock (lockObj)
            {
                if (trenutniMec == null || trenutniMec.Status != StatusIgre.UToku)
                    return;

                // Pronađi igrača u meču i pomjeri reket
                if (trenutniMec.Igrac1?.Id == igracId)
                {
                    trenutniMec.PozicijaReketa1 += smjer;
                    trenutniMec.PozicijaReketa1 = Math.Max(0, Math.Min(Mec.VISINA_TERENA - Mec.VISINA_REKETA, trenutniMec.PozicijaReketa1));
                }
                else if (trenutniMec.Igrac2?.Id == igracId)
                {
                    trenutniMec.PozicijaReketa2 += smjer;
                    trenutniMec.PozicijaReketa2 = Math.Max(0, Math.Min(Mec.VISINA_TERENA - Mec.VISINA_REKETA, trenutniMec.PozicijaReketa2));
                }
            }
        }

        static void PrimiTcpKonekcije()
        {
            while (serverAktivan)
            {
                try
                {
                    if (tcpSocket.Poll(0, SelectMode.SelectRead))
                    {
                        Socket clientSocket = tcpSocket.Accept();
                        Thread clientThread = new Thread(() => ObradiTcpKlijenta(clientSocket));
                        clientThread.IsBackground = true;
                        clientThread.Start();
                    }
                    else
                    {
                        Thread.Sleep(50);
                    }
                }
                catch (Exception ex)
                {
                    if (serverAktivan)
                        Console.WriteLine($"[TCP Greška] {ex.Message}");
                }
            }
        }

        static void ObradiTcpKlijenta(Socket client)
        {
            int igracId = -1;
            try
            {
                byte[] buffer = new byte[4096];

                while (serverAktivan && client.Connected)
                {
                    if (client.Available > 0)
                    {
                        int bytesRead = client.Receive(buffer);
                        if (bytesRead > 0)
                        {
                            byte[] data = new byte[bytesRead];
                            Array.Copy(buffer, data, bytesRead);
                            Poruka poruka = Poruka.Deserijalizuj(data);

                            // Registruj TCP konekciju za igrača
                            if (igracId == -1 && poruka.IgracId > 0)
                            {
                                igracId = poruka.IgracId;
                                lock (lockObj)
                                {
                                    tcpKlijenti[igracId] = client;
                                }
                                Console.WriteLine($"[TCP] Igrač {igracId} povezan");
                            }
                        }
                    }
                    Thread.Sleep(10);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[TCP Greška] Klijent: {ex.Message}");
            }
            finally
            {
                if (igracId > 0)
                {
                    lock (lockObj)
                    {
                        tcpKlijenti.Remove(igracId);
                    }
                }
                client?.Close();
            }
        }

        static void PosaljiTcpPoruku(Socket client, Poruka poruka)
        {
            try
            {
                if (client != null && client.Connected)
                {
                    byte[] data = poruka.Serijalizuj();
                    client.Send(data);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[TCP Greška] Slanje: {ex.Message}");
            }
        }

        static void PosaljiSvimaPrekoTcp(Poruka poruka)
        {
            lock (lockObj)
            {
                foreach (var kvp in tcpKlijenti)
                {
                    PosaljiTcpPoruku(kvp.Value, poruka);
                }
            }
        }

        static void PokreniTurnir()
        {
            lock (lockObj)
            {
                if (prijavljeniIgraci.Count < 2)
                {
                    Console.WriteLine("[TURNIR] Potrebno je najmanje 2 igrača za turnir!");
                    return;
                }

                if (turnirUToku)
                {
                    Console.WriteLine("[TURNIR] Turnir je već u toku!");
                    return;
                }

                Console.WriteLine("\n=== TURNIR POČINJE ===");
                turnirUToku = true;

                // Generiši nasumične parove
                GenerisiParove();

                // Obavijesti sve igrače
                Poruka obavijest = new Poruka(TipPoruke.TurnirPocetak);
                obavijest.Tekst = $"Turnir počinje! Broj igrača: {prijavljeniIgraci.Count}";
                PosaljiSvimaPrekoTcp(obavijest);

                // Pokreni prvi meč
                Thread mecThread = new Thread(IgrajTurnir);
                mecThread.IsBackground = true;
                mecThread.Start();
            }
        }

        static void GenerisiParove()
        {
            parovi.Clear();
            List<Igrac> shuffled = prijavljeniIgraci.OrderBy(x => Guid.NewGuid()).ToList();

            for (int i = 0; i < shuffled.Count - 1; i += 2)
            {
                parovi.Enqueue(new Tuple<Igrac, Igrac>(shuffled[i], shuffled[i + 1]));
                Console.WriteLine($"[PAR] {shuffled[i].Ime} vs {shuffled[i + 1].Ime}");
            }

            // Ako je neparan broj igrača, zadnji ima bye
            if (shuffled.Count % 2 == 1)
            {
                Console.WriteLine($"[BYE] {shuffled.Last().Ime} ima slobodan prolaz");
                shuffled.Last().BrojPobeda++;
            }
        }

        static void IgrajTurnir()
        {
            while (parovi.Count > 0 && serverAktivan)
            {
                var par = parovi.Dequeue();
                IgrajMec(par.Item1, par.Item2);
                Thread.Sleep(2000); // Pauza između mečeva
            }

            // Turnir završen
            lock (lockObj)
            {
                turnirUToku = false;
            }

            Console.WriteLine("\n=== TURNIR ZAVRŠEN ===");
            PrikaziRangListu();
            PosaljiRangListu();
        }

        static void IgrajMec(Igrac igrac1, Igrac igrac2)
        {
            Console.WriteLine($"\n--- MEČ: {igrac1.Ime} vs {igrac2.Ime} ---");

            lock (lockObj)
            {
                trenutniMec = new Mec();
                trenutniMec.Igrac1 = igrac1;
                trenutniMec.Igrac2 = igrac2;
                trenutniMec.Status = StatusIgre.UToku;
            }

            // Obavijesti igrače o početku meča
            Poruka mecPocetak = new Poruka(TipPoruke.MecPocetak);
            mecPocetak.Podaci = trenutniMec.Serijalizuj();

            if (tcpKlijenti.ContainsKey(igrac1.Id))
                PosaljiTcpPoruku(tcpKlijenti[igrac1.Id], mecPocetak);
            if (tcpKlijenti.ContainsKey(igrac2.Id))
                PosaljiTcpPoruku(tcpKlijenti[igrac2.Id], mecPocetak);

            // Game loop
            while (trenutniMec.Status == StatusIgre.UToku && serverAktivan)
            {
                lock (lockObj)
                {
                    // Ažuriraj lopticu
                    trenutniMec.AzurirajLopticu();
                }

                // Vizualizacija na serveru
                NacrtajTeren();

                // Pošalji stanje igre igračima putem UDP
                PosaljiStanjeIgre();

                Thread.Sleep(100); // ~10 FPS
            }

            // Meč završen
            ZavrsiMec();
        }

        static void PosaljiStanjeIgre()
        {
            lock (lockObj)
            {
                if (trenutniMec == null) return;

                Poruka stanje = new Poruka(TipPoruke.StanjeIgre);
                stanje.Podaci = trenutniMec.Serijalizuj();

                // Pošalji igraču 1
                if (trenutniMec.Igrac1 != null && udpEndpointi.ContainsKey(trenutniMec.Igrac1.Id))
                {
                    stanje.IgracId = trenutniMec.Igrac1.Id;
                    PosaljiUdpOdgovor(stanje, udpEndpointi[trenutniMec.Igrac1.Id]);
                }

                // Pošalji igraču 2
                if (trenutniMec.Igrac2 != null && udpEndpointi.ContainsKey(trenutniMec.Igrac2.Id))
                {
                    stanje.IgracId = trenutniMec.Igrac2.Id;
                    PosaljiUdpOdgovor(stanje, udpEndpointi[trenutniMec.Igrac2.Id]);
                }
            }
        }

        static void ZavrsiMec()
        {
            lock (lockObj)
            {
                if (trenutniMec == null) return;

                Igrac pobjednik = trenutniMec.DobaviPobjednika();
                if (pobjednik != null)
                {
                    pobjednik.BrojPobeda++;
                    Console.WriteLine($"\n*** POBJEDNIK: {pobjednik.Ime} {pobjednik.Prezime} ***");
                }

                // Ažuriraj bodove
                trenutniMec.Igrac1.BrojOsvojenihBodova += trenutniMec.RezultatIgrac1;
                trenutniMec.Igrac2.BrojOsvojenihBodova += trenutniMec.RezultatIgrac2;

                odigraniMecevi.Add(trenutniMec);

                // Obavijesti igrače
                Poruka mecKraj = new Poruka(TipPoruke.MecKraj);
                mecKraj.Podaci = trenutniMec.Serijalizuj();
                mecKraj.Tekst = $"Meč završen! Pobjednik: {pobjednik?.Ime ?? "Nerješeno"}";

                if (tcpKlijenti.ContainsKey(trenutniMec.Igrac1.Id))
                    PosaljiTcpPoruku(tcpKlijenti[trenutniMec.Igrac1.Id], mecKraj);
                if (tcpKlijenti.ContainsKey(trenutniMec.Igrac2.Id))
                    PosaljiTcpPoruku(tcpKlijenti[trenutniMec.Igrac2.Id], mecKraj);

                // Pošalji rang listu svima
                PosaljiRangListu();

                trenutniMec = null;
            }
        }

        static void NacrtajTeren()
        {
            lock (lockObj)
            {
                if (trenutniMec == null) return;

                Console.SetCursorPosition(0, 10);

                // Header sa rezultatom
                string igrac1Ime = trenutniMec.Igrac1?.Ime ?? "???";
                string igrac2Ime = trenutniMec.Igrac2?.Ime ?? "???";
                string rezultat = $"  {igrac1Ime} [{trenutniMec.RezultatIgrac1}] - [{trenutniMec.RezultatIgrac2}] {igrac2Ime}";
                Console.WriteLine(rezultat.PadRight(Mec.SIRINA_TERENA + 4));

                // Gornja ivica
                Console.WriteLine("+" + new string('-', Mec.SIRINA_TERENA) + "+");

                // Teren
                int lopticaX = (int)Math.Round(trenutniMec.LopticaX);
                int lopticaY = (int)Math.Round(trenutniMec.LopticaY);

                for (int y = 0; y < Mec.VISINA_TERENA; y++)
                {
                    StringBuilder linija = new StringBuilder("|");

                    for (int x = 0; x < Mec.SIRINA_TERENA; x++)
                    {
                        // Reket igrača 1 (lijevo)
                        if (x == 1 && y >= trenutniMec.PozicijaReketa1 && y < trenutniMec.PozicijaReketa1 + Mec.VISINA_REKETA)
                        {
                            linija.Append("║");
                        }
                        // Reket igrača 2 (desno)
                        else if (x == Mec.SIRINA_TERENA - 2 && y >= trenutniMec.PozicijaReketa2 && y < trenutniMec.PozicijaReketa2 + Mec.VISINA_REKETA)
                        {
                            linija.Append("║");
                        }
                        // Loptica
                        else if (x == lopticaX && y == lopticaY)
                        {
                            linija.Append("O");
                        }
                        // Srednja linija
                        else if (x == Mec.SIRINA_TERENA / 2)
                        {
                            linija.Append(y % 2 == 0 ? ":" : " ");
                        }
                        else
                        {
                            linija.Append(" ");
                        }
                    }

                    linija.Append("|");
                    Console.WriteLine(linija.ToString());
                }

                // Donja ivica
                Console.WriteLine("+" + new string('-', Mec.SIRINA_TERENA) + "+");

                // Debug info
                Console.WriteLine($"  Loptica: ({lopticaX}, {lopticaY}) Smjer: ({trenutniMec.LopticaSmjerX:F1}, {trenutniMec.LopticaSmjerY:F1})".PadRight(50));
                Console.WriteLine($"  Reket1 Y: {trenutniMec.PozicijaReketa1}  Reket2 Y: {trenutniMec.PozicijaReketa2}".PadRight(50));
            }
        }

        static void PrikaziIgrace()
        {
            lock (lockObj)
            {
                Console.WriteLine("\n=== PRIJAVLJENI IGRAČI ===");
                if (prijavljeniIgraci.Count == 0)
                {
                    Console.WriteLine("  Nema prijavljenih igrača.");
                }
                else
                {
                    foreach (var igrac in prijavljeniIgraci)
                    {
                        string tcpStatus = tcpKlijenti.ContainsKey(igrac.Id) ? "TCP OK" : "TCP -";
                        Console.WriteLine($"  [{igrac.Id}] {igrac.Ime} {igrac.Prezime} - {tcpStatus}");
                    }
                }
                Console.WriteLine();
            }
        }

        static void PrikaziRangListu()
        {
            lock (lockObj)
            {
                Console.WriteLine("\n=== RANG LISTA ===");
                Console.WriteLine("  #   Ime             Pobede  Bodovi");
                Console.WriteLine("  -----------------------------------");

                var sortiraniIgraci = prijavljeniIgraci
                    .OrderByDescending(i => i.BrojPobeda)
                    .ThenByDescending(i => i.BrojOsvojenihBodova)
                    .ToList();

                int rang = 1;
                foreach (var igrac in sortiraniIgraci)
                {
                    Console.WriteLine($"  {rang,-3} {(igrac.Ime + " " + igrac.Prezime).PadRight(15)} {igrac.BrojPobeda,-7} {igrac.BrojOsvojenihBodova}");
                    rang++;
                }
                Console.WriteLine();
            }
        }

        static void PosaljiRangListu()
        {
            lock (lockObj)
            {
                var sortiraniIgraci = prijavljeniIgraci
                    .OrderByDescending(i => i.BrojPobeda)
                    .ThenByDescending(i => i.BrojOsvojenihBodova)
                    .ToList();

                // Kreiraj string rang liste
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("=== RANG LISTA ===");
                sb.AppendLine("#   Ime             Pobede  Bodovi");
                sb.AppendLine("-----------------------------------");

                int rang = 1;
                foreach (var igrac in sortiraniIgraci)
                {
                    sb.AppendLine($"{rang,-3} {(igrac.Ime + " " + igrac.Prezime).PadRight(15)} {igrac.BrojPobeda,-7} {igrac.BrojOsvojenihBodova}");
                    rang++;
                }

                Poruka poruka = new Poruka(TipPoruke.RangLista);
                poruka.Tekst = sb.ToString();
                PosaljiSvimaPrekoTcp(poruka);
            }
        }
    }
}
