using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Domain;

namespace Client
{
    class Program
    {
        // Mrežna konfiguracija
        private const string SERVER_IP = "127.0.0.1";
        private const int SERVER_UDP_PORT = 5000;
        private const int SERVER_TCP_PORT = 5001;

        // Soketi
        private static Socket udpSocket;
        private static Socket tcpSocket;
        private static EndPoint serverUdpEndPoint;

        // Podaci o igraču
        private static Igrac mojIgrac;
        private static bool prijavljen = false;
        private static bool uIgri = false;
        private static Mec trenutniMec;

        // Thread sync
        private static object lockObj = new object();
        private static bool klijentAktivan = true;

        static void Main(string[] args)
        {
            Console.Title = "PingPong Klijent";
            Console.WriteLine("=== PING PONG KLIJENT ===\n");

            // Unos podataka
            Console.Write("Unesite ime: ");
            string ime = Console.ReadLine();
            Console.Write("Unesite prezime: ");
            string prezime = Console.ReadLine();

            mojIgrac = new Igrac(ime, prezime);

            // Inicijalizuj UDP socket
            udpSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            udpSocket.Bind(new IPEndPoint(IPAddress.Any, 0));
            serverUdpEndPoint = new IPEndPoint(IPAddress.Parse(SERVER_IP), SERVER_UDP_PORT);

            // Pošalji prijavu
            PrijaviSe();

            if (!prijavljen)
            {
                Console.WriteLine("Prijava nije uspjela. Pritisnite bilo koju tipku za izlaz.");
                Console.ReadKey();
                return;
            }

            // Poveži se TCP-om
            PoveziTcp();

            // Pokreni thread za prijem UDP poruka
            Thread udpThread = new Thread(PrimiUdpPoruke);
            udpThread.IsBackground = true;
            udpThread.Start();

            // Pokreni thread za prijem TCP poruka
            Thread tcpThread = new Thread(PrimiTcpPoruke);
            tcpThread.IsBackground = true;
            tcpThread.Start();

            Console.WriteLine("\nČekam početak igre...");
            Console.WriteLine("Kontrole: Strelica GORE / DOLE za pomeranje reketa");
            Console.WriteLine("          Q za izlaz\n");

            // Glavni loop - handle input
            while (klijentAktivan)
            {
                // Non-blocking key input (Console.KeyAvailable)
                if (Console.KeyAvailable)
                {
                    ConsoleKeyInfo key = Console.ReadKey(true);

                    switch (key.Key)
                    {
                        case ConsoleKey.UpArrow:
                            PosaljiKomanduPomeranja(TipPoruke.PomjeriGore);
                            break;
                        case ConsoleKey.DownArrow:
                            PosaljiKomanduPomeranja(TipPoruke.PomjeriDole);
                            break;
                        case ConsoleKey.Q:
                            klijentAktivan = false;
                            break;
                    }
                }

                Thread.Sleep(16); // ~60 FPS input polling
            }

            // Cleanup
            udpSocket?.Close();
            tcpSocket?.Close();
            Console.WriteLine("\nKlijent zatvoren.");
        }

        static void PrijaviSe()
        {
            try
            {
                Console.WriteLine($"Prijavljujem se na server {SERVER_IP}:{SERVER_UDP_PORT}...");

                Poruka zahtjev = new Poruka(TipPoruke.ZahtjevZaPrijavu);
                zahtjev.Podaci = mojIgrac.Serijalizuj();

                byte[] data = zahtjev.Serijalizuj();
                udpSocket.SendTo(data, serverUdpEndPoint);

                // Čekaj odgovor (sa timeout-om)
                udpSocket.ReceiveTimeout = 5000;
                byte[] buffer = new byte[4096];
                EndPoint remoteEP = new IPEndPoint(IPAddress.Any, 0);

                int bytesRead = udpSocket.ReceiveFrom(buffer, ref remoteEP);
                byte[] response = new byte[bytesRead];
                Array.Copy(buffer, response, bytesRead);
                Poruka odgovor = Poruka.Deserijalizuj(response);

                if (odgovor.Tip == TipPoruke.PotvrdaPrijave)
                {
                    mojIgrac = Igrac.Deserijalizuj(odgovor.Podaci);
                    prijavljen = true;
                    Console.WriteLine($"Prijava uspješna! Vaš ID: {mojIgrac.Id}");
                    Console.WriteLine($"Poruka: {odgovor.Tekst}");
                }
                else
                {
                    Console.WriteLine($"Prijava odbijena: {odgovor.Tekst}");
                }

                // Vrati timeout na infinity za game loop
                udpSocket.ReceiveTimeout = 0;
            }
            catch (SocketException ex)
            {
                Console.WriteLine($"Greška pri prijavi: {ex.Message}");
            }
        }

        static void PoveziTcp()
        {
            try
            {
                tcpSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                tcpSocket.Connect(SERVER_IP, SERVER_TCP_PORT);
                Console.WriteLine($"TCP konekcija uspostavljena.");

                // Pošalji identifikaciju
                Poruka ident = new Poruka(TipPoruke.Ping);
                ident.IgracId = mojIgrac.Id;
                byte[] data = ident.Serijalizuj();
                tcpSocket.Send(data);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"TCP greška: {ex.Message}");
            }
        }

        static void PrimiUdpPoruke()
        {
            byte[] buffer = new byte[4096];
            EndPoint remoteEP = new IPEndPoint(IPAddress.Any, 0);

            while (klijentAktivan)
            {
                try
                {
                    if (udpSocket.Available > 0)
                    {
                        int bytesRead = udpSocket.ReceiveFrom(buffer, ref remoteEP);
                        byte[] data = new byte[bytesRead];
                        Array.Copy(buffer, data, bytesRead);
                        ObradiUdpPoruku(data);
                    }
                    else
                    {
                        Thread.Sleep(10);
                    }
                }
                catch (SocketException)
                {
                    // Ignoriši timeout greške
                }
                catch (Exception ex)
                {
                    if (klijentAktivan)
                        Console.WriteLine($"UDP greška: {ex.Message}");
                }
            }
        }

        static void ObradiUdpPoruku(byte[] data)
        {
            try
            {
                Poruka poruka = Poruka.Deserijalizuj(data);

                switch (poruka.Tip)
                {
                    case TipPoruke.StanjeIgre:
                        lock (lockObj)
                        {
                            trenutniMec = Mec.Deserijalizuj(poruka.Podaci);
                            if (trenutniMec.Status == StatusIgre.UToku)
                            {
                                uIgri = true;
                                NacrtajTeren();
                            }
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Greška obrade UDP: {ex.Message}");
            }
        }

        static void PrimiTcpPoruke()
        {
            byte[] buffer = new byte[4096];

            while (klijentAktivan && tcpSocket != null && tcpSocket.Connected)
            {
                try
                {
                    if (tcpSocket.Available > 0)
                    {
                        int bytesRead = tcpSocket.Receive(buffer);
                        if (bytesRead > 0)
                        {
                            byte[] data = new byte[bytesRead];
                            Array.Copy(buffer, data, bytesRead);
                            ObradiTcpPoruku(data);
                        }
                    }
                    else
                    {
                        Thread.Sleep(50);
                    }
                }
                catch (Exception ex)
                {
                    if (klijentAktivan)
                        Console.WriteLine($"TCP greška: {ex.Message}");
                    break;
                }
            }
        }

        static void ObradiTcpPoruku(byte[] data)
        {
            try
            {
                Poruka poruka = Poruka.Deserijalizuj(data);

                switch (poruka.Tip)
                {
                    case TipPoruke.TurnirPocetak:
                        Console.Clear();
                        Console.WriteLine("\n*** TURNIR POČINJE! ***");
                        Console.WriteLine(poruka.Tekst);
                        break;

                    case TipPoruke.MecPocetak:
                        Console.Clear();
                        lock (lockObj)
                        {
                            trenutniMec = Mec.Deserijalizuj(poruka.Podaci);
                            uIgri = true;
                        }
                        Console.WriteLine("\n*** MEČ POČINJE! ***");
                        Console.WriteLine($"{trenutniMec.Igrac1?.Ime} vs {trenutniMec.Igrac2?.Ime}");

                        // Odredi koji sam ja igrač
                        if (trenutniMec.Igrac1?.Id == mojIgrac.Id)
                            Console.WriteLine("Vi ste igrač na LIJEVOJ strani (||)");
                        else
                            Console.WriteLine("Vi ste igrač na DESNOJ strani (||)");
                        break;

                    case TipPoruke.MecKraj:
                        lock (lockObj)
                        {
                            uIgri = false;
                            trenutniMec = Mec.Deserijalizuj(poruka.Podaci);
                        }
                        Console.SetCursorPosition(0, 30);
                        Console.WriteLine("\n*** MEČ ZAVRŠEN! ***");
                        Console.WriteLine(poruka.Tekst);
                        break;

                    case TipPoruke.RangLista:
                        Console.SetCursorPosition(0, 35);
                        Console.WriteLine("\n" + poruka.Tekst);
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Greška obrade TCP: {ex.Message}");
            }
        }

        static void PosaljiKomanduPomeranja(TipPoruke tip)
        {
            if (!uIgri) return;

            try
            {
                Poruka komanda = new Poruka(tip);
                komanda.IgracId = mojIgrac.Id;
                byte[] data = komanda.Serijalizuj();
                udpSocket.SendTo(data, serverUdpEndPoint);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Greška slanja komande: {ex.Message}");
            }
        }

        static void NacrtajTeren()
        {
            lock (lockObj)
            {
                if (trenutniMec == null) return;

                Console.SetCursorPosition(0, 5);

                // Header sa rezultatom
                string igrac1Ime = trenutniMec.Igrac1?.Ime ?? "???";
                string igrac2Ime = trenutniMec.Igrac2?.Ime ?? "???";
                string rezultat = $"  {igrac1Ime} [{trenutniMec.RezultatIgrac1}] - [{trenutniMec.RezultatIgrac2}] {igrac2Ime}";
                Console.WriteLine(rezultat.PadRight(Mec.SIRINA_TERENA + 4));

                // Označi mene
                if (trenutniMec.Igrac1?.Id == mojIgrac.Id)
                    Console.WriteLine("  [VI ste lijevo]".PadRight(Mec.SIRINA_TERENA + 4));
                else
                    Console.WriteLine("  [VI ste desno]".PadRight(Mec.SIRINA_TERENA + 4));

                // Gornja ivica
                Console.WriteLine("+" + new string('-', Mec.SIRINA_TERENA) + "+");

                // Teren
                int lopticaX = (int)Math.Round(trenutniMec.LopticaX);
                int lopticaY = (int)Math.Round(trenutniMec.LopticaY);

                for (int y = 0; y < Mec.VISINA_TERENA; y++)
                {
                    StringBuilder linija = new StringBuilder("|");

                    for (int x = 0; x < Mec.SIRINA_TERENA; x++)
                    {
                        // Reket igrača 1 (lijevo)
                        if (x == 1 && y >= trenutniMec.PozicijaReketa1 && y < trenutniMec.PozicijaReketa1 + Mec.VISINA_REKETA)
                        {
                            linija.Append("║");
                        }
                        // Reket igrača 2 (desno)
                        else if (x == Mec.SIRINA_TERENA - 2 && y >= trenutniMec.PozicijaReketa2 && y < trenutniMec.PozicijaReketa2 + Mec.VISINA_REKETA)
                        {
                            linija.Append("║");
                        }
                        // Loptica
                        else if (x == lopticaX && y == lopticaY)
                        {
                            linija.Append("O");
                        }
                        // Srednja linija
                        else if (x == Mec.SIRINA_TERENA / 2)
                        {
                            linija.Append(y % 2 == 0 ? ":" : " ");
                        }
                        else
                        {
                            linija.Append(" ");
                        }
                    }

                    linija.Append("|");
                    Console.WriteLine(linija.ToString());
                }

                // Donja ivica
                Console.WriteLine("+" + new string('-', Mec.SIRINA_TERENA) + "+");
            }
        }
    }
}
