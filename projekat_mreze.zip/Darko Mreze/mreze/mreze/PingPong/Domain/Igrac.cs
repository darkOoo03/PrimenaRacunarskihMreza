using System;
using System.IO;
using System.Net;

namespace Domain
{
    [Serializable]
    public class Igrac
    {
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public int BrojPobeda { get; set; }
        public int BrojOsvojenihBodova { get; set; }
        public int PozicijaReketa { get; set; }

        // Mrežni podaci
        public IPEndPoint UdpEndPoint { get; set; }
        public int TcpPort { get; set; }
        public int Id { get; set; }

        public Igrac()
        {
            BrojPobeda = 0;
            BrojOsvojenihBodova = 0;
            PozicijaReketa = 10; // Početna pozicija na sredini (teren je 20 visok)
        }

        public Igrac(string ime, string prezime) : this()
        {
            Ime = ime;
            Prezime = prezime;
        }

        // Serijalizacija u bajtove
        public byte[] Serijalizuj()
        {
            using (MemoryStream ms = new MemoryStream())
            using (BinaryWriter writer = new BinaryWriter(ms))
            {
                writer.Write(Id);
                writer.Write(Ime ?? "");
                writer.Write(Prezime ?? "");
                writer.Write(BrojPobeda);
                writer.Write(BrojOsvojenihBodova);
                writer.Write(PozicijaReketa);
                writer.Write(TcpPort);
                return ms.ToArray();
            }
        }

        // Deserijalizacija iz bajtova
        public static Igrac Deserijalizuj(byte[] data)
        {
            using (MemoryStream ms = new MemoryStream(data))
            using (BinaryReader reader = new BinaryReader(ms))
            {
                Igrac igrac = new Igrac();
                igrac.Id = reader.ReadInt32();
                igrac.Ime = reader.ReadString();
                igrac.Prezime = reader.ReadString();
                igrac.BrojPobeda = reader.ReadInt32();
                igrac.BrojOsvojenihBodova = reader.ReadInt32();
                igrac.PozicijaReketa = reader.ReadInt32();
                igrac.TcpPort = reader.ReadInt32();
                return igrac;
            }
        }

        public override string ToString()
        {
            return $"{Ime} {Prezime} - Pobede: {BrojPobeda}, Bodovi: {BrojOsvojenihBodova}";
        }
    }
}
