using System;
using System.IO;
using System.Text;

namespace Domain
{
    public enum TipPoruke
    {
        // Prijava
        ZahtjevZaPrijavu,
        PotvrdaPrijave,
        OdbijanaPrijava,

        // Turnir
        TurnirPocetak,
        MecPocetak,
        MecKraj,
        RangLista,

        // Igra
        StanjeIgre,
        KomandaIgraca,
        PomjeriGore,
        PomjeriDole,

        // Sistem
        Ping,
        Pong,
        Greska
    }

    [Serializable]
    public class Poruka
    {
        public TipPoruke Tip { get; set; }
        public int IgracId { get; set; }
        public byte[] Podaci { get; set; }
        public string Tekst { get; set; }

        public Poruka()
        {
            Podaci = new byte[0];
            Tekst = "";
        }

        public Poruka(TipPoruke tip) : this()
        {
            Tip = tip;
        }

        public Poruka(TipPoruke tip, string tekst) : this(tip)
        {
            Tekst = tekst;
        }

        public Poruka(TipPoruke tip, byte[] podaci) : this(tip)
        {
            Podaci = podaci;
        }

        // Serijalizacija
        public byte[] Serijalizuj()
        {
            using (MemoryStream ms = new MemoryStream())
            using (BinaryWriter writer = new BinaryWriter(ms))
            {
                writer.Write((int)Tip);
                writer.Write(IgracId);
                writer.Write(Tekst ?? "");
                writer.Write(Podaci?.Length ?? 0);
                if (Podaci != null && Podaci.Length > 0)
                {
                    writer.Write(Podaci);
                }
                return ms.ToArray();
            }
        }

        // Deserijalizacija
        public static Poruka Deserijalizuj(byte[] data)
        {
            using (MemoryStream ms = new MemoryStream(data))
            using (BinaryReader reader = new BinaryReader(ms))
            {
                Poruka poruka = new Poruka();
                poruka.Tip = (TipPoruke)reader.ReadInt32();
                poruka.IgracId = reader.ReadInt32();
                poruka.Tekst = reader.ReadString();
                int dataLen = reader.ReadInt32();
                if (dataLen > 0)
                {
                    poruka.Podaci = reader.ReadBytes(dataLen);
                }
                else
                {
                    poruka.Podaci = new byte[0];
                }
                return poruka;
            }
        }
    }
}
