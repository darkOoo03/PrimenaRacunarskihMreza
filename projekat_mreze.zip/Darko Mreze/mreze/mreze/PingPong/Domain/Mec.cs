using System;
using System.IO;

namespace Domain
{
    public enum StatusIgre
    {
        CekaNaIgrace,
        UPripremi,
        UToku,
        Pauza,
        Zavrsen
    }

    [Serializable]
    public class Mec
    {
        // Dimenzije terena
        public const int SIRINA_TERENA = 40;
        public const int VISINA_TERENA = 20;
        public const int VISINA_REKETA = 4;
        public const int POENI_ZA_POBEDU = 10;

        // Igrači
        public Igrac Igrac1 { get; set; }
        public Igrac Igrac2 { get; set; }

        // Pozicije reketa (Y koordinata)
        public int PozicijaReketa1 { get; set; }
        public int PozicijaReketa2 { get; set; }

        // Koordinate loptice
        public float LopticaX { get; set; }
        public float LopticaY { get; set; }
        public float LopticaSmjerX { get; set; }
        public float LopticaSmjerY { get; set; }

        // Rezultat
        public int RezultatIgrac1 { get; set; }
        public int RezultatIgrac2 { get; set; }

        // Status
        public StatusIgre Status { get; set; }
        public int MecId { get; set; }

        public Mec()
        {
            Status = StatusIgre.CekaNaIgrace;
            ResetujLopticu();
            PozicijaReketa1 = VISINA_TERENA / 2 - VISINA_REKETA / 2;
            PozicijaReketa2 = VISINA_TERENA / 2 - VISINA_REKETA / 2;
            RezultatIgrac1 = 0;
            RezultatIgrac2 = 0;
        }

        public void ResetujLopticu()
        {
            LopticaX = SIRINA_TERENA / 2;
            LopticaY = VISINA_TERENA / 2;
            // Nasumičan smjer
            Random rand = new Random();
            LopticaSmjerX = rand.Next(0, 2) == 0 ? -1 : 1;
            LopticaSmjerY = (float)(rand.NextDouble() * 2 - 1); // -1 do 1
        }

        public void AzurirajLopticu()
        {
            // Pomjeri lopticu
            LopticaX += LopticaSmjerX;
            LopticaY += LopticaSmjerY;

            // Odbijanje od gornje/donje ivice
            if (LopticaY <= 0 || LopticaY >= VISINA_TERENA - 1)
            {
                LopticaSmjerY = -LopticaSmjerY;
                LopticaY = Math.Max(0, Math.Min(VISINA_TERENA - 1, LopticaY));
            }

            // Provjera sudara sa reketom igrača 1 (lijeva strana)
            if (LopticaX <= 2)
            {
                if (LopticaY >= PozicijaReketa1 && LopticaY < PozicijaReketa1 + VISINA_REKETA)
                {
                    LopticaSmjerX = Math.Abs(LopticaSmjerX); // Okreni na desno
                    // Dodaj spin na osnovu gdje je loptica pogodila reket
                    float pogodak = (LopticaY - PozicijaReketa1) / VISINA_REKETA;
                    LopticaSmjerY = (pogodak - 0.5f) * 2;
                }
                else if (LopticaX <= 0)
                {
                    // Igrač 2 je osvojio poen
                    RezultatIgrac2++;
                    ResetujLopticu();
                    ProvjeriPobjednika();
                }
            }

            // Provjera sudara sa reketom igrača 2 (desna strana)
            if (LopticaX >= SIRINA_TERENA - 3)
            {
                if (LopticaY >= PozicijaReketa2 && LopticaY < PozicijaReketa2 + VISINA_REKETA)
                {
                    LopticaSmjerX = -Math.Abs(LopticaSmjerX); // Okreni na lijevo
                    // Dodaj spin na osnovu gdje je loptica pogodila reket
                    float pogodak = (LopticaY - PozicijaReketa2) / VISINA_REKETA;
                    LopticaSmjerY = (pogodak - 0.5f) * 2;
                }
                else if (LopticaX >= SIRINA_TERENA - 1)
                {
                    // Igrač 1 je osvojio poen
                    RezultatIgrac1++;
                    ResetujLopticu();
                    ProvjeriPobjednika();
                }
            }
        }

        private void ProvjeriPobjednika()
        {
            if (RezultatIgrac1 >= POENI_ZA_POBEDU || RezultatIgrac2 >= POENI_ZA_POBEDU)
            {
                Status = StatusIgre.Zavrsen;
            }
        }

        public Igrac DobaviPobjednika()
        {
            if (Status != StatusIgre.Zavrsen) return null;
            return RezultatIgrac1 >= POENI_ZA_POBEDU ? Igrac1 : Igrac2;
        }

        // Serijalizacija
        public byte[] Serijalizuj()
        {
            using (MemoryStream ms = new MemoryStream())
            using (BinaryWriter writer = new BinaryWriter(ms))
            {
                writer.Write(MecId);
                writer.Write((int)Status);
                writer.Write(PozicijaReketa1);
                writer.Write(PozicijaReketa2);
                writer.Write(LopticaX);
                writer.Write(LopticaY);
                writer.Write(LopticaSmjerX);
                writer.Write(LopticaSmjerY);
                writer.Write(RezultatIgrac1);
                writer.Write(RezultatIgrac2);

                // Serijalizuj igrače ako postoje
                if (Igrac1 != null)
                {
                    writer.Write(true);
                    byte[] igrac1Data = Igrac1.Serijalizuj();
                    writer.Write(igrac1Data.Length);
                    writer.Write(igrac1Data);
                }
                else
                {
                    writer.Write(false);
                }

                if (Igrac2 != null)
                {
                    writer.Write(true);
                    byte[] igrac2Data = Igrac2.Serijalizuj();
                    writer.Write(igrac2Data.Length);
                    writer.Write(igrac2Data);
                }
                else
                {
                    writer.Write(false);
                }

                return ms.ToArray();
            }
        }

        // Deserijalizacija
        public static Mec Deserijalizuj(byte[] data)
        {
            using (MemoryStream ms = new MemoryStream(data))
            using (BinaryReader reader = new BinaryReader(ms))
            {
                Mec mec = new Mec();
                mec.MecId = reader.ReadInt32();
                mec.Status = (StatusIgre)reader.ReadInt32();
                mec.PozicijaReketa1 = reader.ReadInt32();
                mec.PozicijaReketa2 = reader.ReadInt32();
                mec.LopticaX = reader.ReadSingle();
                mec.LopticaY = reader.ReadSingle();
                mec.LopticaSmjerX = reader.ReadSingle();
                mec.LopticaSmjerY = reader.ReadSingle();
                mec.RezultatIgrac1 = reader.ReadInt32();
                mec.RezultatIgrac2 = reader.ReadInt32();

                if (reader.ReadBoolean())
                {
                    int len = reader.ReadInt32();
                    byte[] igrac1Data = reader.ReadBytes(len);
                    mec.Igrac1 = Igrac.Deserijalizuj(igrac1Data);
                }

                if (reader.ReadBoolean())
                {
                    int len = reader.ReadInt32();
                    byte[] igrac2Data = reader.ReadBytes(len);
                    mec.Igrac2 = Igrac.Deserijalizuj(igrac2Data);
                }

                return mec;
            }
        }

        public override string ToString()
        {
            string igrac1Ime = Igrac1 != null ? $"{Igrac1.Ime} {Igrac1.Prezime}" : "???";
            string igrac2Ime = Igrac2 != null ? $"{Igrac2.Ime} {Igrac2.Prezime}" : "???";
            return $"{igrac1Ime} [{RezultatIgrac1}] vs [{RezultatIgrac2}] {igrac2Ime}";
        }
    }
}
